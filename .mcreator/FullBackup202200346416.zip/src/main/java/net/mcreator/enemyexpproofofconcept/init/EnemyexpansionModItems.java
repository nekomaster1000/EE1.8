
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.enemyexpproofofconcept.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;

import net.mcreator.enemyexpproofofconcept.item.SprintshortsItem;
import net.mcreator.enemyexpproofofconcept.item.SlugvestItem;
import net.mcreator.enemyexpproofofconcept.item.MeatureMeatballItem;
import net.mcreator.enemyexpproofofconcept.item.MeatheadArmorItem;
import net.mcreator.enemyexpproofofconcept.item.HuntsmanPunchItem;
import net.mcreator.enemyexpproofofconcept.EnemyexpansionMod;

public class EnemyexpansionModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, EnemyexpansionMod.MODID);
	public static final RegistryObject<Item> SPRINTERZOMBIE = REGISTRY.register("sprinterzombie_spawn_egg",
			() -> new ForgeSpawnEggItem(EnemyexpansionModEntities.SPRINTERZOMBIE, -14269861, -9273797,
					new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> SLUGGERZOMBIE = REGISTRY.register("sluggerzombie_spawn_egg",
			() -> new ForgeSpawnEggItem(EnemyexpansionModEntities.SLUGGERZOMBIE, -12244867, -10910598,
					new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> FRIGID_ZOMBIE = REGISTRY.register("frigid_zombie_spawn_egg",
			() -> new ForgeSpawnEggItem(EnemyexpansionModEntities.FRIGID_ZOMBIE, -16751762, -11821426,
					new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> EQUESTRIANZOMBIE = REGISTRY.register("equestrianzombie_spawn_egg",
			() -> new ForgeSpawnEggItem(EnemyexpansionModEntities.EQUESTRIANZOMBIE, -7425636, -7711442,
					new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> MEATURE = REGISTRY.register("meature_spawn_egg",
			() -> new ForgeSpawnEggItem(EnemyexpansionModEntities.MEATURE, -6730933, -5081483, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> TARANTULA = REGISTRY.register("tarantula_spawn_egg",
			() -> new ForgeSpawnEggItem(EnemyexpansionModEntities.TARANTULA, -8497616, -7373714,
					new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> SCORPION = REGISTRY.register("scorpion_spawn_egg",
			() -> new ForgeSpawnEggItem(EnemyexpansionModEntities.SCORPION, -11782091, -7439758,
					new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> MEATHEAD_ARMOR_HELMET = REGISTRY.register("meathead_armor_helmet", () -> new MeatheadArmorItem.Helmet());
	public static final RegistryObject<Item> MEATMANZOMBIE = REGISTRY.register("meatmanzombie_spawn_egg",
			() -> new ForgeSpawnEggItem(EnemyexpansionModEntities.MEATMANZOMBIE, -16732241, -6730933,
					new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> SENIORZOMBIE = REGISTRY.register("seniorzombie_spawn_egg",
			() -> new ForgeSpawnEggItem(EnemyexpansionModEntities.SENIORZOMBIE, -13476771, -14997182,
					new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> SLUGVEST_CHESTPLATE = REGISTRY.register("slugvest_chestplate", () -> new SlugvestItem.Chestplate());
	public static final RegistryObject<Item> SPRINTSHORTS_LEGGINGS = REGISTRY.register("sprintshorts_leggings",
			() -> new SprintshortsItem.Leggings());
	public static final RegistryObject<Item> MEATURE_MEATBALL = REGISTRY.register("meature_meatball", () -> new MeatureMeatballItem());
	public static final RegistryObject<Item> HUNTSMANSKELETON = REGISTRY.register("huntsmanskeleton_spawn_egg",
			() -> new ForgeSpawnEggItem(EnemyexpansionModEntities.HUNTSMANSKELETON, -2894893, -10273499,
					new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> HUNTSMAN_PUNCH = REGISTRY.register("huntsman_punch", () -> new HuntsmanPunchItem());
	public static final RegistryObject<Item> WASP = REGISTRY.register("wasp_spawn_egg",
			() -> new ForgeSpawnEggItem(EnemyexpansionModEntities.WASP, -1195197, -830911, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
}

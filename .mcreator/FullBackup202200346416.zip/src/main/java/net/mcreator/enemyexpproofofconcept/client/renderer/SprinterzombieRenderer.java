
package net.mcreator.enemyexpproofofconcept.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.enemyexpproofofconcept.entity.SprinterzombieEntity;
import net.mcreator.enemyexpproofofconcept.client.model.Modelsprinter_zombie;

public class SprinterzombieRenderer extends MobRenderer<SprinterzombieEntity, Modelsprinter_zombie<SprinterzombieEntity>> {
	public SprinterzombieRenderer(EntityRendererProvider.Context context) {
		super(context, new Modelsprinter_zombie(context.bakeLayer(Modelsprinter_zombie.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(SprinterzombieEntity entity) {
		return new ResourceLocation("enemyexpansion:textures/entities/sprinter_zombie.png");
	}
}


package net.mcreator.enemyexpproofofconcept.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.enemyexpproofofconcept.entity.SluggerzombieEntity;
import net.mcreator.enemyexpproofofconcept.client.model.slugger_zombie;

public class SluggerzombieRenderer extends MobRenderer<SluggerzombieEntity, slugger_zombie<SluggerzombieEntity>> {
	public SluggerzombieRenderer(EntityRendererProvider.Context context) {
		super(context, new slugger_zombie(context.bakeLayer(slugger_zombie.LAYER_LOCATION)), 0.6f);
	}

	@Override
	public ResourceLocation getTextureLocation(SluggerzombieEntity entity) {
		return new ResourceLocation("enemyexpansion:textures/entities/slugger_zombie.png");
	}
}

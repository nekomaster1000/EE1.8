package net.mcreator.enemyexpproofofconcept.entity.renderer;

import net.minecraftforge.fml.client.registry.RenderingRegistry;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.util.math.MathHelper;
import net.minecraft.util.ResourceLocation;
import net.minecraft.entity.Entity;
import net.minecraft.client.renderer.model.ModelRenderer;
import net.minecraft.client.renderer.entity.model.EntityModel;
import net.minecraft.client.renderer.entity.MobRenderer;

import net.mcreator.enemyexpproofofconcept.entity.HuntsmanskeletonEntity;

import com.mojang.blaze3d.vertex.IVertexBuilder;
import com.mojang.blaze3d.matrix.MatrixStack;

@OnlyIn(Dist.CLIENT)
public class HuntsmanskeletonRenderer {
	public static class ModelRegisterHandler {
		@SubscribeEvent
		@OnlyIn(Dist.CLIENT)
		public void registerModels(ModelRegistryEvent event) {
			RenderingRegistry.registerEntityRenderingHandler(HuntsmanskeletonEntity.entity, renderManager -> {
				return new MobRenderer(renderManager, new Modelhuntsman(), 0.5f) {

					@Override
					public ResourceLocation getEntityTexture(Entity entity) {
						return new ResourceLocation("enemyexpproofofconcept:textures/huntsman.png");
					}
				};
			});
		}
	}

	// Made with Blockbench 4.2.4
	// Exported for Minecraft version 1.15 - 1.16 with MCP mappings
	// Paste this class into your mod and generate all required imports
	public static class Modelhuntsman extends EntityModel<Entity> {
		private final ModelRenderer all;
		private final ModelRenderer body;
		private final ModelRenderer armour_r1;
		private final ModelRenderer head;
		private final ModelRenderer rightArm;
		private final ModelRenderer rightItem;
		private final ModelRenderer leftArm;
		private final ModelRenderer leftItem;
		private final ModelRenderer rightLeg;
		private final ModelRenderer leftLeg;

		public Modelhuntsman() {
			textureWidth = 64;
			textureHeight = 64;
			all = new ModelRenderer(this);
			all.setRotationPoint(0.0F, 24.0F, 0.0F);
			body = new ModelRenderer(this);
			body.setRotationPoint(0.0F, -22.0F, 0.0F);
			all.addChild(body);
			body.setTextureOffset(0, 52).addBox(-5.0F, -8.2F, -3.0F, 10.0F, 4.0F, 6.0F, 0.0F, false);
			body.setTextureOffset(40, 0).addBox(-4.0F, -8.0F, -2.0F, 8.0F, 16.0F, 4.0F, 0.0F, false);
			armour_r1 = new ModelRenderer(this);
			armour_r1.setRotationPoint(0.0F, -8.0F, 3.0F);
			body.addChild(armour_r1);
			setRotationAngle(armour_r1, 0.0436F, 0.0F, 0.0F);
			armour_r1.setTextureOffset(40, 53).addBox(-5.0F, -0.2F, 0.02F, 10.0F, 11.0F, 0.0F, 0.0F, false);
			head = new ModelRenderer(this);
			head.setRotationPoint(0.0F, -8.0F, 0.0F);
			body.addChild(head);
			head.setTextureOffset(0, 0).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F, 0.0F, false);
			head.setTextureOffset(10, 22).addBox(-7.0F, -6.0F, -6.5F, 14.0F, 1.0F, 13.0F, 0.1F, false);
			head.setTextureOffset(30, 38).addBox(-4.0F, -9.0F, -4.5F, 8.0F, 4.0F, 9.0F, 0.1F, false);
			rightArm = new ModelRenderer(this);
			rightArm.setRotationPoint(-5.0F, -6.0F, 0.0F);
			body.addChild(rightArm);
			rightArm.setTextureOffset(0, 18).addBox(-1.0F, -2.0F, -1.0F, 2.0F, 16.0F, 2.0F, 0.0F, false);
			rightArm.setTextureOffset(0, 43).addBox(-2.0F, -3.0F, -2.0F, 3.0F, 4.0F, 4.0F, 0.0F, false);
			rightArm.setTextureOffset(33, 58).addBox(-1.5F, 6.5F, -2.1F, 3.0F, 2.0F, 4.0F, 0.2F, false);
			rightArm.setTextureOffset(15, 40).addBox(-1.5F, 7.5F, -2.1F, 3.0F, 7.0F, 4.0F, 0.0F, false);
			rightItem = new ModelRenderer(this);
			rightItem.setRotationPoint(-1.0F, 12.0F, 1.0F);
			rightArm.addChild(rightItem);
			leftArm = new ModelRenderer(this);
			leftArm.setRotationPoint(5.0F, -6.0F, 0.0F);
			body.addChild(leftArm);
			leftArm.setTextureOffset(0, 18).addBox(-1.0F, -2.0F, -1.0F, 2.0F, 16.0F, 2.0F, 0.0F, true);
			leftArm.setTextureOffset(0, 43).addBox(-1.0F, -3.0F, -2.0F, 3.0F, 4.0F, 4.0F, 0.0F, true);
			leftArm.setTextureOffset(33, 58).addBox(-1.5F, 6.5F, -2.1F, 3.0F, 2.0F, 4.0F, 0.2F, true);
			leftArm.setTextureOffset(15, 40).addBox(-1.5F, 7.5F, -2.1F, 3.0F, 7.0F, 4.0F, 0.0F, true);
			leftItem = new ModelRenderer(this);
			leftItem.setRotationPoint(1.0F, 12.0F, 1.0F);
			leftArm.addChild(leftItem);
			rightLeg = new ModelRenderer(this);
			rightLeg.setRotationPoint(-2.0F, 8.0F, 0.0F);
			body.addChild(rightLeg);
			rightLeg.setTextureOffset(9, 18).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 14.0F, 2.0F, 0.0F, false);
			leftLeg = new ModelRenderer(this);
			leftLeg.setRotationPoint(2.0F, 8.0F, 0.0F);
			body.addChild(leftLeg);
			leftLeg.setTextureOffset(9, 18).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 14.0F, 2.0F, 0.0F, true);
		}

		@Override
		public void render(MatrixStack matrixStack, IVertexBuilder buffer, int packedLight, int packedOverlay, float red, float green, float blue,
				float alpha) {
			all.render(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
		}

		public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
			modelRenderer.rotateAngleX = x;
			modelRenderer.rotateAngleY = y;
			modelRenderer.rotateAngleZ = z;
		}

		public void setRotationAngles(Entity e, float f, float f1, float f2, float f3, float f4) {
			this.head.rotateAngleY = f3 / (180F / (float) Math.PI);
			this.head.rotateAngleX = f4 / (180F / (float) Math.PI);
			this.rightLeg.rotateAngleX = MathHelper.cos(f * 1.0F) * 1.0F * f1;
			this.rightArm.rotateAngleX = MathHelper.cos(f * 0.6662F + (float) Math.PI) * f1;
			this.leftArm.rotateAngleX = MathHelper.cos(f * 0.6662F) * f1;
			this.leftLeg.rotateAngleX = MathHelper.cos(f * 1.0F) * -1.0F * f1;
		}
	}

}

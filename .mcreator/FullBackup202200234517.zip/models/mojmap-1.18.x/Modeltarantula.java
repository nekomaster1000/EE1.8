// Made with Blockbench 4.4.3
// Exported for Minecraft version 1.17 - 1.18 with Mojang mappings
// Paste this class into your mod and generate all required imports

public class Modeltarantula<T extends Entity> extends EntityModel<T> {
	// This layer location should be baked with EntityRendererProvider.Context in
	// the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(
			new ResourceLocation("modid", "tarantula"), "main");
	private final ModelPart head;
	private final ModelPart body0;
	private final ModelPart body1;
	private final ModelPart legr4;
	private final ModelPart legl4;
	private final ModelPart legr3;
	private final ModelPart legl3;
	private final ModelPart legr2;
	private final ModelPart legl2;
	private final ModelPart legr1;
	private final ModelPart legl1;

	public Modeltarantula(ModelPart root) {
		this.head = root.getChild("head");
		this.body0 = root.getChild("body0");
		this.body1 = root.getChild("body1");
		this.legr4 = root.getChild("legr4");
		this.legl4 = root.getChild("legl4");
		this.legr3 = root.getChild("legr3");
		this.legl3 = root.getChild("legl3");
		this.legr2 = root.getChild("legr2");
		this.legl2 = root.getChild("legl2");
		this.legr1 = root.getChild("legr1");
		this.legl1 = root.getChild("legl1");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();

		PartDefinition head = partdefinition.addOrReplaceChild("head", CubeListBuilder.create().texOffs(32, 42).addBox(
				-4.0F, -4.0F, -9.0F, 8.0F, 8.0F, 8.0F, new CubeDeformation(1.0F)), PartPose.offset(0.0F, 15.0F, -3.0F));

		PartDefinition body0 = partdefinition.addOrReplaceChild("body0", CubeListBuilder.create().texOffs(0, 49).addBox(
				-4.0F, -4.0F, -5.0F, 8.0F, 8.0F, 7.0F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, 15.0F, 0.0F));

		PartDefinition body1 = partdefinition.addOrReplaceChild("body1", CubeListBuilder.create().texOffs(0, 0)
				.addBox(-8.0F, -6.0F, 0.0F, 16.0F, 12.0F, 16.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, 13.5F, 1.0F));

		PartDefinition legr4 = partdefinition.addOrReplaceChild("legr4",
				CubeListBuilder.create().texOffs(0, 41).mirror()
						.addBox(-15.0F, -2.9F, -1.0F, 16.0F, 4.0F, 4.0F, new CubeDeformation(0.0F)).mirror(false),
				PartPose.offsetAndRotation(-6.0F, 15.25F, 6.0F, 0.0F, 0.7854F, -0.7854F));

		PartDefinition legl4 = partdefinition.addOrReplaceChild("legl4",
				CubeListBuilder.create().texOffs(0, 41).addBox(-1.0F, -2.9F, -1.0F, 16.0F, 4.0F, 4.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(6.0F, 15.25F, 6.0F, 0.0F, -0.7854F, 0.7854F));

		PartDefinition legr3 = partdefinition.addOrReplaceChild("legr3",
				CubeListBuilder.create().texOffs(0, 41).mirror()
						.addBox(-15.0F, -2.75F, -1.0F, 16.0F, 4.0F, 4.0F, new CubeDeformation(0.0F)).mirror(false),
				PartPose.offsetAndRotation(-7.0F, 14.75F, 3.0F, 0.0F, 0.2618F, -0.6109F));

		PartDefinition legl3 = partdefinition.addOrReplaceChild("legl3",
				CubeListBuilder.create().texOffs(0, 41).addBox(-1.0F, -2.75F, -1.0F, 16.0F, 4.0F, 4.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(6.0F, 14.75F, 3.0F, 0.0F, -0.2618F, 0.6109F));

		PartDefinition legr2 = partdefinition.addOrReplaceChild("legr2",
				CubeListBuilder.create().texOffs(0, 41).mirror()
						.addBox(-15.0F, -3.0F, -1.0F, 16.0F, 4.0F, 4.0F, new CubeDeformation(0.0F)).mirror(false),
				PartPose.offsetAndRotation(-4.0F, 14.5F, 0.0F, 0.0F, -0.2618F, -0.6109F));

		PartDefinition legl2 = partdefinition.addOrReplaceChild("legl2",
				CubeListBuilder.create().texOffs(0, 41).addBox(-1.0F, -3.0F, -1.0F, 16.0F, 4.0F, 4.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(4.0F, 14.5F, 0.0F, 0.0F, 0.2618F, 0.6109F));

		PartDefinition legr1 = partdefinition.addOrReplaceChild("legr1",
				CubeListBuilder.create().texOffs(0, 41).mirror()
						.addBox(-15.0F, -2.9F, -1.0F, 16.0F, 4.0F, 4.0F, new CubeDeformation(0.0F)).mirror(false),
				PartPose.offsetAndRotation(-3.0F, 14.5F, -3.0F, 0.0F, -0.7854F, -0.7854F));

		PartDefinition legl1 = partdefinition.addOrReplaceChild("legl1",
				CubeListBuilder.create().texOffs(0, 41).addBox(-1.0F, -2.9F, -1.0F, 16.0F, 4.0F, 4.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(3.0F, 14.5F, -3.0F, 0.0F, 0.7854F, 0.7854F));

		return LayerDefinition.create(meshdefinition, 64, 64);
	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay,
			float red, float green, float blue, float alpha) {
		head.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		body0.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		body1.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		legr4.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		legl4.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		legr3.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		legl3.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		legr2.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		legl2.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		legr1.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		legl1.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
	}

	public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw,
			float headPitch) {
		this.head.yRot = netHeadYaw / (180F / (float) Math.PI);
		this.head.xRot = headPitch / (180F / (float) Math.PI);
		this.legr4.xRot = Mth.cos(limbSwing * 1.0F) * 1.0F * limbSwingAmount;
		this.legl1.xRot = Mth.cos(limbSwing * 0.6662F) * limbSwingAmount;
		this.legl3.xRot = Mth.cos(limbSwing * 0.6662F) * limbSwingAmount;
		this.legl2.xRot = Mth.cos(limbSwing * 1.0F) * -1.0F * limbSwingAmount;
		this.legl4.xRot = Mth.cos(limbSwing * 1.0F) * -1.0F * limbSwingAmount;
		this.legr1.xRot = Mth.cos(limbSwing * 0.6662F + (float) Math.PI) * limbSwingAmount;
		this.legr3.xRot = Mth.cos(limbSwing * 0.6662F + (float) Math.PI) * limbSwingAmount;
		this.legr2.xRot = Mth.cos(limbSwing * 1.0F) * 1.0F * limbSwingAmount;
	}
}
// Made with Blockbench 4.4.3
// Exported for Minecraft version 1.17 - 1.18 with Mojang mappings
// Paste this class into your mod and generate all required imports

public class Modelscorpion<T extends Entity> extends EntityModel<T> {
	// This layer location should be baked with EntityRendererProvider.Context in
	// the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(
			new ResourceLocation("modid", "scorpion"), "main");
	private final ModelPart head;
	private final ModelPart torso;
	private final ModelPart r1;
	private final ModelPart l1;
	private final ModelPart r2;
	private final ModelPart l2;
	private final ModelPart r3;
	private final ModelPart l3;
	private final ModelPart armr;
	private final ModelPart arml;

	public Modelscorpion(ModelPart root) {
		this.head = root.getChild("head");
		this.torso = root.getChild("torso");
		this.r1 = root.getChild("r1");
		this.l1 = root.getChild("l1");
		this.r2 = root.getChild("r2");
		this.l2 = root.getChild("l2");
		this.r3 = root.getChild("r3");
		this.l3 = root.getChild("l3");
		this.armr = root.getChild("armr");
		this.arml = root.getChild("arml");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();

		PartDefinition head = partdefinition.addOrReplaceChild("head", CubeListBuilder.create().texOffs(30, 13)
				.addBox(-5.0F, -3.0F, -6.0F, 10.0F, 8.0F, 7.0F, new CubeDeformation(0.02F)),
				PartPose.offset(0.0F, 15.0F, -6.0F));

		PartDefinition torso = partdefinition.addOrReplaceChild("torso", CubeListBuilder.create().texOffs(0, 20)
				.addBox(-4.0F, -3.0F, -3.0F, 8.0F, 7.0F, 10.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, 15.0F, -2.0F));

		PartDefinition stinger = torso.addOrReplaceChild("stinger", CubeListBuilder.create(),
				PartPose.offset(0.0F, 0.0F, 6.0F));

		PartDefinition stinger_r1 = stinger
				.addOrReplaceChild("stinger_r1",
						CubeListBuilder.create().texOffs(0, 0).addBox(-3.0F, -1.636F, -0.5355F, 6.0F, 5.0F, 12.0F,
								new CubeDeformation(0.0F)),
						PartPose.offsetAndRotation(0.0F, 0.0F, -1.0F, 0.7854F, 0.0F, 0.0F));

		PartDefinition stringertorso = stinger.addOrReplaceChild("stringertorso", CubeListBuilder.create(),
				PartPose.offset(0.0F, -8.0F, 5.0F));

		PartDefinition stringertorso_r1 = stringertorso.addOrReplaceChild(
				"stringertorso_r1", CubeListBuilder.create().texOffs(28, 29).addBox(-2.0F, -1.4142F, 0.0F, 4.0F, 3.0F,
						9.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 2.3562F, 0.0F, 0.0F));

		PartDefinition stingerhead = stringertorso.addOrReplaceChild("stingerhead", CubeListBuilder.create(),
				PartPose.offset(0.0F, -6.5F, -6.5F));

		PartDefinition stingerhead_r1 = stingerhead.addOrReplaceChild("stingerhead_r1",
				CubeListBuilder.create().texOffs(29, 47).addBox(-2.0F, -6.1F, -0.2F, 4.0F, 7.0F, 2.0F,
						new CubeDeformation(0.02F)),
				PartPose.offsetAndRotation(0.0F, -0.5F, 0.5F, 2.3562F, 0.0F, 0.0F));

		PartDefinition r1 = partdefinition.addOrReplaceChild("r1",
				CubeListBuilder.create().texOffs(0, 40).mirror()
						.addBox(-11.0F, -1.0F, -1.0F, 12.0F, 2.0F, 2.0F, new CubeDeformation(0.0F)).mirror(false),
				PartPose.offsetAndRotation(-4.0F, 17.0F, -1.0F, 0.0F, -0.2618F, -0.6109F));

		PartDefinition l1 = partdefinition.addOrReplaceChild("l1",
				CubeListBuilder.create().texOffs(0, 40).addBox(-1.0F, -1.0F, -1.0F, 12.0F, 2.0F, 2.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(4.0F, 17.0F, -1.0F, 0.0F, 0.2618F, 0.6109F));

		PartDefinition r2 = partdefinition.addOrReplaceChild("r2",
				CubeListBuilder.create().texOffs(0, 45).mirror()
						.addBox(-11.0F, -1.0F, -1.0F, 12.0F, 2.0F, 2.0F, new CubeDeformation(0.05F)).mirror(false),
				PartPose.offsetAndRotation(-4.0F, 17.0F, 0.0F, 0.0F, 0.2618F, -0.6109F));

		PartDefinition l2 = partdefinition.addOrReplaceChild("l2",
				CubeListBuilder.create().texOffs(0, 45).addBox(-1.0F, -1.0F, -1.0F, 12.0F, 2.0F, 2.0F,
						new CubeDeformation(0.05F)),
				PartPose.offsetAndRotation(4.0F, 17.0F, 0.0F, 0.0F, -0.2618F, 0.6109F));

		PartDefinition r3 = partdefinition.addOrReplaceChild("r3",
				CubeListBuilder.create().texOffs(29, 42).mirror()
						.addBox(-11.0F, -1.0F, -1.0F, 12.0F, 2.0F, 2.0F, new CubeDeformation(0.0F)).mirror(false),
				PartPose.offsetAndRotation(-4.0F, 17.0F, 1.0F, 0.0F, 0.7854F, -0.7854F));

		PartDefinition l3 = partdefinition.addOrReplaceChild("l3",
				CubeListBuilder.create().texOffs(29, 42).addBox(-1.0F, -1.0F, -1.0F, 12.0F, 2.0F, 2.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(4.0F, 17.0F, 1.0F, 0.0F, -0.7854F, 0.7854F));

		PartDefinition armr = partdefinition.addOrReplaceChild("armr",
				CubeListBuilder.create().texOffs(25, 0).mirror()
						.addBox(-8.68F, -1.7834F, -2.438F, 10.0F, 3.0F, 6.0F, new CubeDeformation(0.0F)).mirror(false)
						.texOffs(46, 29).mirror()
						.addBox(-8.68F, -1.7834F, -6.438F, 3.0F, 2.0F, 4.0F, new CubeDeformation(0.0F)).mirror(false),
				PartPose.offsetAndRotation(-4.0F, 19.0F, -7.0F, 0.2967F, -0.1745F, -0.5236F));

		PartDefinition arml = partdefinition.addOrReplaceChild("arml",
				CubeListBuilder.create().texOffs(25, 0)
						.addBox(-1.32F, -1.7834F, -2.438F, 10.0F, 3.0F, 6.0F, new CubeDeformation(0.0F)).texOffs(46, 29)
						.addBox(5.68F, -1.7834F, -6.438F, 3.0F, 2.0F, 4.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(4.0F, 19.0F, -7.0F, 0.2967F, 0.1745F, 0.5236F));

		return LayerDefinition.create(meshdefinition, 64, 64);
	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay,
			float red, float green, float blue, float alpha) {
		head.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		torso.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		r1.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		l1.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		r2.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		l2.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		r3.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		l3.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		armr.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		arml.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
	}

	public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw,
			float headPitch) {
		this.head.yRot = netHeadYaw / (180F / (float) Math.PI);
		this.head.xRot = headPitch / (180F / (float) Math.PI);
		this.r2.xRot = Mth.cos(limbSwing * 1.0F) * 1.0F * limbSwingAmount;
		this.r3.xRot = Mth.cos(limbSwing * 0.6662F + (float) Math.PI) * limbSwingAmount;
		this.l1.xRot = Mth.cos(limbSwing * 0.6662F) * limbSwingAmount;
		this.l2.xRot = Mth.cos(limbSwing * 1.0F) * -1.0F * limbSwingAmount;
		this.l3.xRot = Mth.cos(limbSwing * 0.6662F) * limbSwingAmount;
		this.r1.xRot = Mth.cos(limbSwing * 0.6662F + (float) Math.PI) * limbSwingAmount;
	}
}
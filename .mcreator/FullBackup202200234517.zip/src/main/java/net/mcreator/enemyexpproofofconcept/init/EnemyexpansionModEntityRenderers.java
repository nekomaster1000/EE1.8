
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.enemyexpproofofconcept.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.mcreator.enemyexpproofofconcept.client.renderer.TarantulaRenderer;
import net.mcreator.enemyexpproofofconcept.client.renderer.SprinterzombieRenderer;
import net.mcreator.enemyexpproofofconcept.client.renderer.SluggerzombieRenderer;
import net.mcreator.enemyexpproofofconcept.client.renderer.SeniorzombieRenderer;
import net.mcreator.enemyexpproofofconcept.client.renderer.ScorpionRenderer;
import net.mcreator.enemyexpproofofconcept.client.renderer.MeatureRenderer;
import net.mcreator.enemyexpproofofconcept.client.renderer.MeatmanzombieRenderer;
import net.mcreator.enemyexpproofofconcept.client.renderer.FrigidZombieRenderer;
import net.mcreator.enemyexpproofofconcept.client.renderer.EquestrianzombieRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class EnemyexpansionModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(EnemyexpansionModEntities.SPRINTERZOMBIE.get(), SprinterzombieRenderer::new);
		event.registerEntityRenderer(EnemyexpansionModEntities.SLUGGERZOMBIE.get(), SluggerzombieRenderer::new);
		event.registerEntityRenderer(EnemyexpansionModEntities.FRIGID_ZOMBIE.get(), FrigidZombieRenderer::new);
		event.registerEntityRenderer(EnemyexpansionModEntities.EQUESTRIANZOMBIE.get(), EquestrianzombieRenderer::new);
		event.registerEntityRenderer(EnemyexpansionModEntities.MEATURE.get(), MeatureRenderer::new);
		event.registerEntityRenderer(EnemyexpansionModEntities.TARANTULA.get(), TarantulaRenderer::new);
		event.registerEntityRenderer(EnemyexpansionModEntities.SCORPION.get(), ScorpionRenderer::new);
		event.registerEntityRenderer(EnemyexpansionModEntities.MEATMANZOMBIE.get(), MeatmanzombieRenderer::new);
		event.registerEntityRenderer(EnemyexpansionModEntities.SENIORZOMBIE.get(), SeniorzombieRenderer::new);
	}
}

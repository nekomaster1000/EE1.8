
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.enemyexpproofofconcept.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.enemyexpproofofconcept.entity.TarantulaEntity;
import net.mcreator.enemyexpproofofconcept.entity.SprinterzombieEntity;
import net.mcreator.enemyexpproofofconcept.entity.SluggerzombieEntity;
import net.mcreator.enemyexpproofofconcept.entity.SeniorzombieEntity;
import net.mcreator.enemyexpproofofconcept.entity.ScorpionEntity;
import net.mcreator.enemyexpproofofconcept.entity.MeatureEntity;
import net.mcreator.enemyexpproofofconcept.entity.MeatmanzombieEntity;
import net.mcreator.enemyexpproofofconcept.entity.FrigidZombieEntity;
import net.mcreator.enemyexpproofofconcept.entity.EquestrianzombieEntity;
import net.mcreator.enemyexpproofofconcept.EnemyexpansionMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class EnemyexpansionModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITIES, EnemyexpansionMod.MODID);
	public static final RegistryObject<EntityType<SprinterzombieEntity>> SPRINTERZOMBIE = register("sprinterzombie",
			EntityType.Builder.<SprinterzombieEntity>of(SprinterzombieEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(SprinterzombieEntity::new)

					.sized(0.45f, 1.95f));
	public static final RegistryObject<EntityType<SluggerzombieEntity>> SLUGGERZOMBIE = register("sluggerzombie",
			EntityType.Builder.<SluggerzombieEntity>of(SluggerzombieEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(SluggerzombieEntity::new)

					.sized(0.6f, 2.3f));
	public static final RegistryObject<EntityType<FrigidZombieEntity>> FRIGID_ZOMBIE = register("frigid_zombie",
			EntityType.Builder.<FrigidZombieEntity>of(FrigidZombieEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(FrigidZombieEntity::new).fireImmune().sized(0.8f, 0.95f));
	public static final RegistryObject<EntityType<EquestrianzombieEntity>> EQUESTRIANZOMBIE = register("equestrianzombie",
			EntityType.Builder.<EquestrianzombieEntity>of(EquestrianzombieEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(EquestrianzombieEntity::new)

					.sized(0.65f, 2f));
	public static final RegistryObject<EntityType<MeatureEntity>> MEATURE = register("meature",
			EntityType.Builder.<MeatureEntity>of(MeatureEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
					.setUpdateInterval(3).setCustomClientFactory(MeatureEntity::new)

					.sized(0.6f, 1f));
	public static final RegistryObject<EntityType<TarantulaEntity>> TARANTULA = register("tarantula",
			EntityType.Builder.<TarantulaEntity>of(TarantulaEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(TarantulaEntity::new)

					.sized(1.5f, 1.1f));
	public static final RegistryObject<EntityType<ScorpionEntity>> SCORPION = register("scorpion",
			EntityType.Builder.<ScorpionEntity>of(ScorpionEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
					.setUpdateInterval(3).setCustomClientFactory(ScorpionEntity::new)

					.sized(1.5f, 1.1f));
	public static final RegistryObject<EntityType<MeatmanzombieEntity>> MEATMANZOMBIE = register("meatmanzombie",
			EntityType.Builder.<MeatmanzombieEntity>of(MeatmanzombieEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(MeatmanzombieEntity::new)

					.sized(0.6f, 2f));
	public static final RegistryObject<EntityType<SeniorzombieEntity>> SENIORZOMBIE = register("seniorzombie",
			EntityType.Builder.<SeniorzombieEntity>of(SeniorzombieEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(SeniorzombieEntity::new)

					.sized(1f, 2.7f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			SprinterzombieEntity.init();
			SluggerzombieEntity.init();
			FrigidZombieEntity.init();
			EquestrianzombieEntity.init();
			MeatureEntity.init();
			TarantulaEntity.init();
			ScorpionEntity.init();
			MeatmanzombieEntity.init();
			SeniorzombieEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(SPRINTERZOMBIE.get(), SprinterzombieEntity.createAttributes().build());
		event.put(SLUGGERZOMBIE.get(), SluggerzombieEntity.createAttributes().build());
		event.put(FRIGID_ZOMBIE.get(), FrigidZombieEntity.createAttributes().build());
		event.put(EQUESTRIANZOMBIE.get(), EquestrianzombieEntity.createAttributes().build());
		event.put(MEATURE.get(), MeatureEntity.createAttributes().build());
		event.put(TARANTULA.get(), TarantulaEntity.createAttributes().build());
		event.put(SCORPION.get(), ScorpionEntity.createAttributes().build());
		event.put(MEATMANZOMBIE.get(), MeatmanzombieEntity.createAttributes().build());
		event.put(SENIORZOMBIE.get(), SeniorzombieEntity.createAttributes().build());
	}
}

package net.mcreator.enemyexpproofofconcept.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.BlockPos;

public class ZombieBurningProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (world.getBlockState(new BlockPos(x, y, z)).getLightEmission(world, new BlockPos(x, y, z)) >= 14) {
			if (world.canSeeSkyFromBelowWater(new BlockPos(x, y, z)) && !entity.isInWater()) {
				entity.setSecondsOnFire(10);
			}
		}
	}
}

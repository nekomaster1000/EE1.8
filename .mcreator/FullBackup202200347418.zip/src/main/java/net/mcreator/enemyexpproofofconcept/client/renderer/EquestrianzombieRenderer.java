
package net.mcreator.enemyexpproofofconcept.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.enemyexpproofofconcept.entity.EquestrianzombieEntity;
import net.mcreator.enemyexpproofofconcept.client.model.Modelequestrian_zombie;

public class EquestrianzombieRenderer extends MobRenderer<EquestrianzombieEntity, Modelequestrian_zombie<EquestrianzombieEntity>> {
	public EquestrianzombieRenderer(EntityRendererProvider.Context context) {
		super(context, new Modelequestrian_zombie(context.bakeLayer(Modelequestrian_zombie.LAYER_LOCATION)), 0.6f);
	}

	@Override
	public ResourceLocation getTextureLocation(EquestrianzombieEntity entity) {
		return new ResourceLocation("enemyexpansion:textures/entities/equestrian_zombie.png");
	}
}

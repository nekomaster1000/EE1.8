
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.enemyexpproofofconcept.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.enemyexpproofofconcept.client.renderer.WaspRenderer;
import net.mcreator.enemyexpproofofconcept.client.renderer.TarantulaRenderer;
import net.mcreator.enemyexpproofofconcept.client.renderer.SprinterRenderer;
import net.mcreator.enemyexpproofofconcept.client.renderer.SluggerRenderer;
import net.mcreator.enemyexpproofofconcept.client.renderer.SeniorzombieRenderer;
import net.mcreator.enemyexpproofofconcept.client.renderer.ScorpionRenderer;
import net.mcreator.enemyexpproofofconcept.client.renderer.PheromoneSummonRenderer;
import net.mcreator.enemyexpproofofconcept.client.renderer.MeatureRenderer;
import net.mcreator.enemyexpproofofconcept.client.renderer.MeatmanzombieRenderer;
import net.mcreator.enemyexpproofofconcept.client.renderer.HuntsmanskeletonRenderer;
import net.mcreator.enemyexpproofofconcept.client.renderer.FrigidZombieRenderer;
import net.mcreator.enemyexpproofofconcept.client.renderer.EquestrianzombieRenderer;
import net.mcreator.enemyexpproofofconcept.client.renderer.CeilingTarantulaRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class EnemyexpansionModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(EnemyexpansionModEntities.FRIGID_ZOMBIE.get(), FrigidZombieRenderer::new);
		event.registerEntityRenderer(EnemyexpansionModEntities.EQUESTRIANZOMBIE.get(), EquestrianzombieRenderer::new);
		event.registerEntityRenderer(EnemyexpansionModEntities.MEATURE.get(), MeatureRenderer::new);
		event.registerEntityRenderer(EnemyexpansionModEntities.TARANTULA.get(), TarantulaRenderer::new);
		event.registerEntityRenderer(EnemyexpansionModEntities.SCORPION.get(), ScorpionRenderer::new);
		event.registerEntityRenderer(EnemyexpansionModEntities.MEATMANZOMBIE.get(), MeatmanzombieRenderer::new);
		event.registerEntityRenderer(EnemyexpansionModEntities.SENIORZOMBIE.get(), SeniorzombieRenderer::new);
		event.registerEntityRenderer(EnemyexpansionModEntities.HUNTSMANSKELETON.get(), HuntsmanskeletonRenderer::new);
		event.registerEntityRenderer(EnemyexpansionModEntities.HUNTSMAN_PUNCH.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(EnemyexpansionModEntities.WASP.get(), WaspRenderer::new);
		event.registerEntityRenderer(EnemyexpansionModEntities.PHEROMONE_SUMMON.get(), PheromoneSummonRenderer::new);
		event.registerEntityRenderer(EnemyexpansionModEntities.PHEROMONE_PROJECTILE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(EnemyexpansionModEntities.CEILING_TARANTULA.get(), CeilingTarantulaRenderer::new);
		event.registerEntityRenderer(EnemyexpansionModEntities.SPRINTER.get(), SprinterRenderer::new);
		event.registerEntityRenderer(EnemyexpansionModEntities.SLUGGER.get(), SluggerRenderer::new);
	}
}


package net.mcreator.enemyexpproofofconcept.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.enemyexpproofofconcept.entity.SeniorzombieEntity;
import net.mcreator.enemyexpproofofconcept.client.model.Modelsenior_zombie;

public class SeniorzombieRenderer extends MobRenderer<SeniorzombieEntity, Modelsenior_zombie<SeniorzombieEntity>> {
	public SeniorzombieRenderer(EntityRendererProvider.Context context) {
		super(context, new Modelsenior_zombie(context.bakeLayer(Modelsenior_zombie.LAYER_LOCATION)), 0.6f);
	}

	@Override
	public ResourceLocation getTextureLocation(SeniorzombieEntity entity) {
		return new ResourceLocation("enemyexpansion:textures/entities/senior_zombie.png");
	}
}

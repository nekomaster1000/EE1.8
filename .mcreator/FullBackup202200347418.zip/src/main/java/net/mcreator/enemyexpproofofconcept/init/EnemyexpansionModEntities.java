
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.enemyexpproofofconcept.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.enemyexpproofofconcept.entity.WaspEntity;
import net.mcreator.enemyexpproofofconcept.entity.TarantulaEntity;
import net.mcreator.enemyexpproofofconcept.entity.SprinterEntity;
import net.mcreator.enemyexpproofofconcept.entity.SluggerEntity;
import net.mcreator.enemyexpproofofconcept.entity.SeniorzombieEntity;
import net.mcreator.enemyexpproofofconcept.entity.ScorpionEntity;
import net.mcreator.enemyexpproofofconcept.entity.PheromoneSummonEntity;
import net.mcreator.enemyexpproofofconcept.entity.PheromoneProjectileEntity;
import net.mcreator.enemyexpproofofconcept.entity.MeatureEntity;
import net.mcreator.enemyexpproofofconcept.entity.MeatmanzombieEntity;
import net.mcreator.enemyexpproofofconcept.entity.HuntsmanskeletonEntity;
import net.mcreator.enemyexpproofofconcept.entity.HuntsmanPunchEntity;
import net.mcreator.enemyexpproofofconcept.entity.FrigidZombieEntity;
import net.mcreator.enemyexpproofofconcept.entity.EquestrianzombieEntity;
import net.mcreator.enemyexpproofofconcept.entity.CeilingTarantulaEntity;
import net.mcreator.enemyexpproofofconcept.EnemyexpansionMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class EnemyexpansionModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITIES, EnemyexpansionMod.MODID);
	public static final RegistryObject<EntityType<FrigidZombieEntity>> FRIGID_ZOMBIE = register("frigid_zombie",
			EntityType.Builder.<FrigidZombieEntity>of(FrigidZombieEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(FrigidZombieEntity::new).fireImmune().sized(0.8f, 0.95f));
	public static final RegistryObject<EntityType<EquestrianzombieEntity>> EQUESTRIANZOMBIE = register("equestrianzombie",
			EntityType.Builder.<EquestrianzombieEntity>of(EquestrianzombieEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(EquestrianzombieEntity::new)

					.sized(0.65f, 2f));
	public static final RegistryObject<EntityType<MeatureEntity>> MEATURE = register("meature",
			EntityType.Builder.<MeatureEntity>of(MeatureEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
					.setUpdateInterval(3).setCustomClientFactory(MeatureEntity::new).fireImmune().sized(0.5f, 1f));
	public static final RegistryObject<EntityType<TarantulaEntity>> TARANTULA = register("tarantula",
			EntityType.Builder.<TarantulaEntity>of(TarantulaEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(TarantulaEntity::new)

					.sized(1.5f, 1.1f));
	public static final RegistryObject<EntityType<ScorpionEntity>> SCORPION = register("scorpion",
			EntityType.Builder.<ScorpionEntity>of(ScorpionEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
					.setUpdateInterval(3).setCustomClientFactory(ScorpionEntity::new)

					.sized(1.5f, 1.1f));
	public static final RegistryObject<EntityType<MeatmanzombieEntity>> MEATMANZOMBIE = register("meatmanzombie",
			EntityType.Builder.<MeatmanzombieEntity>of(MeatmanzombieEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(MeatmanzombieEntity::new).fireImmune().sized(0.6f, 1.95f));
	public static final RegistryObject<EntityType<SeniorzombieEntity>> SENIORZOMBIE = register("seniorzombie",
			EntityType.Builder.<SeniorzombieEntity>of(SeniorzombieEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(SeniorzombieEntity::new)

					.sized(1f, 2.7f));
	public static final RegistryObject<EntityType<HuntsmanskeletonEntity>> HUNTSMANSKELETON = register("huntsmanskeleton",
			EntityType.Builder.<HuntsmanskeletonEntity>of(HuntsmanskeletonEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(HuntsmanskeletonEntity::new)

					.sized(0.5f, 1.95f));
	public static final RegistryObject<EntityType<HuntsmanPunchEntity>> HUNTSMAN_PUNCH = register("projectile_huntsman_punch",
			EntityType.Builder.<HuntsmanPunchEntity>of(HuntsmanPunchEntity::new, MobCategory.MISC).setCustomClientFactory(HuntsmanPunchEntity::new)
					.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<WaspEntity>> WASP = register("wasp",
			EntityType.Builder.<WaspEntity>of(WaspEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
					.setUpdateInterval(3).setCustomClientFactory(WaspEntity::new)

					.sized(0.45f, 1.6f));
	public static final RegistryObject<EntityType<PheromoneSummonEntity>> PHEROMONE_SUMMON = register("pheromone_summon",
			EntityType.Builder.<PheromoneSummonEntity>of(PheromoneSummonEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(PheromoneSummonEntity::new)

					.sized(0.45f, 1.6f));
	public static final RegistryObject<EntityType<PheromoneProjectileEntity>> PHEROMONE_PROJECTILE = register("projectile_pheromone_projectile",
			EntityType.Builder.<PheromoneProjectileEntity>of(PheromoneProjectileEntity::new, MobCategory.MISC)
					.setCustomClientFactory(PheromoneProjectileEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
					.setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<CeilingTarantulaEntity>> CEILING_TARANTULA = register("ceiling_tarantula",
			EntityType.Builder.<CeilingTarantulaEntity>of(CeilingTarantulaEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(CeilingTarantulaEntity::new)

					.sized(1.5f, 1.1f));
	public static final RegistryObject<EntityType<SprinterEntity>> SPRINTER = register("sprinter",
			EntityType.Builder.<SprinterEntity>of(SprinterEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
					.setUpdateInterval(3).setCustomClientFactory(SprinterEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<SluggerEntity>> SLUGGER = register("slugger",
			EntityType.Builder.<SluggerEntity>of(SluggerEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
					.setUpdateInterval(3).setCustomClientFactory(SluggerEntity::new)

					.sized(0.6f, 1.8f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			FrigidZombieEntity.init();
			EquestrianzombieEntity.init();
			MeatureEntity.init();
			TarantulaEntity.init();
			ScorpionEntity.init();
			MeatmanzombieEntity.init();
			SeniorzombieEntity.init();
			HuntsmanskeletonEntity.init();
			WaspEntity.init();
			PheromoneSummonEntity.init();
			CeilingTarantulaEntity.init();
			SprinterEntity.init();
			SluggerEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(FRIGID_ZOMBIE.get(), FrigidZombieEntity.createAttributes().build());
		event.put(EQUESTRIANZOMBIE.get(), EquestrianzombieEntity.createAttributes().build());
		event.put(MEATURE.get(), MeatureEntity.createAttributes().build());
		event.put(TARANTULA.get(), TarantulaEntity.createAttributes().build());
		event.put(SCORPION.get(), ScorpionEntity.createAttributes().build());
		event.put(MEATMANZOMBIE.get(), MeatmanzombieEntity.createAttributes().build());
		event.put(SENIORZOMBIE.get(), SeniorzombieEntity.createAttributes().build());
		event.put(HUNTSMANSKELETON.get(), HuntsmanskeletonEntity.createAttributes().build());
		event.put(WASP.get(), WaspEntity.createAttributes().build());
		event.put(PHEROMONE_SUMMON.get(), PheromoneSummonEntity.createAttributes().build());
		event.put(CEILING_TARANTULA.get(), CeilingTarantulaEntity.createAttributes().build());
		event.put(SPRINTER.get(), SprinterEntity.createAttributes().build());
		event.put(SLUGGER.get(), SluggerEntity.createAttributes().build());
	}
}
